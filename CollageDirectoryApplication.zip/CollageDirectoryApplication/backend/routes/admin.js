const express = require("express");
const {
  getStudents,
  addStudent,
  deleteStudent,
  getFaculty,
  addFaculty,
  deleteFaculty,
  getStudentStats,
  getFacultyStats,
} = require("../controllers/adminController");
const router = express.Router();

// CRUD operations for students
router.get("/students", getStudents);
router.post("/students", addStudent);
router.delete("/students/:id", deleteStudent);

// CRUD operations for faculty
router.get("/faculty", getFaculty);
router.post("/faculty", addFaculty);
router.delete("/faculty/:id", deleteFaculty);

// Stats for dashboard
router.get("/stats/students", getStudentStats);
router.get("/stats/faculty", getFacultyStats);

module.exports = router;
