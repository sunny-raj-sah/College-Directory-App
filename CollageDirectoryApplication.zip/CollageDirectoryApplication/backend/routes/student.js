const express = require("express");
const {
  getStudentProfile,
  searchStudents,
  getFacultyAdvisors,
} = require("../controllers/studentController");
const router = express.Router();

// Get logged-in student's profile
router.get("/profile", getStudentProfile);

// Search for other students
router.get("/search", searchStudents);

// Get assigned faculty advisors
router.get("/advisors", getFacultyAdvisors);

module.exports = router;
