const express = require("express");
const { registerUser, loginUser } = require("../controllers/authController"); // Ensure the functions are imported

const router = express.Router();
const authController = require("../controllers/authController");
// POST request for user registration
router.post("/register", registerUser);

// POST request for user login
router.post("/login", loginUser);

// Signup route
router.post("/signup", authController.signup);

module.exports = router;
