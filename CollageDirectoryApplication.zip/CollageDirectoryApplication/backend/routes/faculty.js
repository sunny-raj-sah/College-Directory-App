const express = require("express");
const {
  getFacultyProfile,
  updateFacultyProfile,
} = require("../controllers/facultyController");
const router = express.Router();

router.get("/profile", getFacultyProfile);
router.put("/profile", updateFacultyProfile);

module.exports = router;
