const FacultyProfile = require("../models/FacultyProfile");

exports.getFacultyProfile = async (req, res) => {
  const profile = await FacultyProfile.findOne({ user: req.user.id }).populate(
    "coursesTaught"
  );
  res.json(profile);
};

exports.updateFacultyProfile = async (req, res) => {
  const updatedProfile = await FacultyProfile.findOneAndUpdate(
    { user: req.user.id },
    req.body,
    { new: true }
  );
  res.json(updatedProfile);
};
