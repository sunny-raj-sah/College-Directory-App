const StudentProfile = require("../models/StudentProfile");
const FacultyProfile = require("../models/FacultyProfile");
const { ObjectId } = require('mongodb');

// Fetch all students
exports.getStudents = async (req, res) => {
  try {
    const students = await StudentProfile.find();
    res.status(200).json(students);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching students" });
  }
};

// Add a new student
exports.addStudent = async (req, res) => {
  try {
    const newStudent = new StudentProfile(req.body);
    await newStudent.save();
    res.status(201).json(newStudent);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error adding student" });
  }
};

// Delete a student
exports.deleteStudent = async (req, res) => {
  try {
    const { id } = req.params;
    await StudentProfile.findByIdAndDelete(id);
    res.status(200).json({ success: true, message: "Student deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error deleting student" });
  }
};

// Fetch all faculty members
exports.getFaculty = async (req, res) => {
  try {
    const faculty = await FacultyProfile.find();
    res.status(200).json(faculty);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching faculty" });
  }
};

// Add a new faculty member
exports.addFaculty = async (req, res) => {
  try {
    const newFaculty = new FacultyProfile(req.body);
    await newFaculty.save();
    res.status(201).json(newFaculty);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error adding faculty" });
  }
};

// Delete a faculty member
exports.deleteFaculty = async (req, res) => {
  try {
    const { id } = req.params;
    await FacultyProfile.findByIdAndDelete(id);
    res.status(200).json({ success: true, message: "Faculty deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Error deleting faculty" });
  }
};

// Fetch student stats for dashboard
exports.getStudentStats = async (req, res) => {
  try {
    // Dummy data for example; replace with actual aggregation queries
    const data = [
      { month: "Jan", students: 120 },
      { month: "Feb", students: 140 },
      { month: "Mar", students: 130 },
      // Add more data as needed
    ];
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching student stats" });
  }
};

// Fetch faculty stats for dashboard
exports.getFacultyStats = async (req, res) => {
  try {
    // Dummy data for example; replace with actual aggregation queries
    const data = [
      { faculty: "Dr. Smith", courses: 5 },
      { faculty: "Dr. Johnson", courses: 3 },
      // Add more data as needed
    ];
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ success: false, message: "Error fetching faculty stats" });
  }
};
