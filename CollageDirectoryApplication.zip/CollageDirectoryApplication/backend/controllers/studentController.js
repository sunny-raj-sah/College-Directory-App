const StudentProfile = require("../models/StudentProfile");
const FacultyProfile = require("../models/FacultyProfile");

// Get student's own profile
exports.getStudentProfile = async (req, res) => {
  try {
    const student = await StudentProfile.findById(req.user.id); // Assuming user ID is available in req.user
    res.json(student);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

// Search for other students
exports.searchStudents = async (req, res) => {
  const { query } = req.query;
  try {
    const students = await StudentProfile.find({
      $or: [
        { name: { $regex: query, $options: "i" } },
        { department: { $regex: query, $options: "i" } },
        { year: { $regex: query, $options: "i" } },
      ],
    });
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

// Get faculty advisors
exports.getFacultyAdvisors = async (req, res) => {
  try {
    const advisors = await FacultyProfile.find({ students: req.user.id }); // Assuming advisors have a 'students' field
    res.json(advisors);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};
