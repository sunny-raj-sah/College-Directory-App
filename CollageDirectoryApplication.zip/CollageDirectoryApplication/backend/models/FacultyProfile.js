const mongoose = require("mongoose");

const facultyProfileSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  department: { type: String, required: true },
  coursesTaught: [{ type: mongoose.Schema.Types.ObjectId, ref: "Course" }],
});

const FacultyProfile = mongoose.model("FacultyProfile", facultyProfileSchema);
module.exports = FacultyProfile;
