const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema({
  name: { type: String, required: true },
  code: { type: String, required: true, unique: true },
  department: { type: String, required: true },
  faculty: { type: mongoose.Schema.Types.ObjectId, ref: "FacultyProfile" },
  studentsEnrolled: [
    { type: mongoose.Schema.Types.ObjectId, ref: "StudentProfile" },
  ],
});

const Course = mongoose.model("Course", courseSchema);
module.exports = Course;
