// src/utils/axiosInstance.js
import axios from "axios";

// Create a new axios instance with the base URL and headers
const axiosInstance = axios.create({
  baseURL: "http://localhost:5000/api", // Ensure this matches your backend's base URL
  headers: {
    "Content-Type": "application/json", // Specify that requests will send JSON
  },
});

// Add an interceptor to include the token in the Authorization header
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token"); // Retrieve token from localStorage
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`; // Attach token to header
    }
    return config; // Return the config so the request can be sent
  },
  (error) => {
    return Promise.reject(error); // Handle request errors
  }
);

export default axiosInstance;
