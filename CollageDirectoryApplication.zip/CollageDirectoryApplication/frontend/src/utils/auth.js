// /frontend/src/utils/auth.js
export const getToken = () => localStorage.getItem("token");

export const setToken = (token) => {
  localStorage.setItem("token", token);
};

export const removeToken = () => {
  localStorage.removeItem("token");
};

export const getUserRole = () => {
  const token = getToken();
  if (token) {
    const user = JSON.parse(atob(token.split(".")[1]));
    return user.role;
  }
  return null;
};
