import React, { useEffect, useState } from "react";
import axiosInstance from "../utils/axiosInstance";

const StudentDashboard = () => {
  const [studentProfile, setStudentProfile] = useState({});
  const [searchResults, setSearchResults] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [facultyAdvisors, setFacultyAdvisors] = useState([]);

  // Fetch the student's profile on page load
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await axiosInstance.get("/student/profile");
        setStudentProfile(response.data);
      } catch (error) {
        console.error("Error fetching student profile:", error);
      }
    };
    fetchProfile();
  }, []);

  // Handle search input and update search results
  const handleSearch = async () => {
    try {
      const response = await axiosInstance.get(
        `/student/search?query=${searchQuery}`
      );
      setSearchResults(response.data);
    } catch (error) {
      console.error("Error fetching search results:", error);
    }
  };

  // Fetch faculty advisors on page load
  useEffect(() => {
    const fetchAdvisors = async () => {
      try {
        const response = await axiosInstance.get("/student/advisors");
        setFacultyAdvisors(response.data);
      } catch (error) {
        console.error("Error fetching advisors:", error);
      }
    };
    fetchAdvisors();
  }, []);

  return (
    <div className="student-dashboard">
      {/* Section A: View Personal Profile */}
      <section className="profile-section">
        <h2>Personal Profile</h2>
        <img src={studentProfile.photo} alt="Student" />
        <p>
          <strong>Name:</strong> {studentProfile.name}
        </p>
        <p>
          <strong>Contact:</strong> {studentProfile.contact}
        </p>
        <p>
          <strong>Courses:</strong> {studentProfile.courses}
        </p>
        <p>
          <strong>Grades:</strong> {studentProfile.grades}
        </p>
        <p>
          <strong>Attendance:</strong> {studentProfile.attendance}
        </p>
      </section>

      {/* Section B: Search for Other Students */}
      <section className="search-section">
        <h2>Search for Other Students</h2>
        <input
          type="text"
          placeholder="Search by name, department, or year"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button onClick={handleSearch}>Search</button>
        <ul>
          {searchResults.map((student) => (
            <li key={student.id}>
              {student.name} - {student.department}, Year: {student.year}
            </li>
          ))}
        </ul>
      </section>

      {/* Section C: Contact Faculty Advisors */}
      <section className="advisors-section">
        <h2>Faculty Advisors</h2>
        <ul>
          {facultyAdvisors.map((advisor) => (
            <li key={advisor.id}>
              {advisor.name} - {advisor.email} - {advisor.phone}
              <a href={`mailto:${advisor.email}`}>Email</a>
              <a href={`tel:${advisor.phone}`}>Call</a>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
};

export default StudentDashboard;
