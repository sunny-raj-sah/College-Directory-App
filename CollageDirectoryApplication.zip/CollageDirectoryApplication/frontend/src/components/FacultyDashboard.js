// src/components/FacultyDashboard.js
import React, { useState, useEffect } from "react";
import axios from "../utils/axiosInstance"; // Ensure the correct path
import "../App.css";

const FacultyDashboard = () => {
  const [classList, setClassList] = useState([]);
  const [profile, setProfile] = useState({
    officeHours: "",
    email: "",
    phone: "",
  });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    const fetchClassList = async () => {
      try {
        const response = await axios.get("/faculty/class-list");
        setClassList(response.data);
      } catch (error) {
        console.error("Error fetching class list:", error);
      }
    };

    const fetchProfile = async () => {
      try {
        const response = await axios.get("/faculty/profile");
        setProfile(response.data);
      } catch (error) {
        console.error("Error fetching profile:", error);
      }
    };

    fetchClassList();
    fetchProfile();
  }, []);

  const handleProfileChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    try {
      await axios.put("/faculty/profile", profile);
      alert("Profile updated successfully");
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };

  return (
    <div className="faculty-dashboard">
      <h1>Faculty Dashboard</h1>

      <div className="class-list">
        <h2>Manage Class List</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Photo</th>
              <th>Contact</th>
            </tr>
          </thead>
          <tbody>
            {classList.map((student) => (
              <tr key={student.id}>
                <td>{student.name}</td>
                <td>
                  <img
                    src={student.photo}
                    alt={student.name}
                    className="student-photo"
                  />
                </td>
                <td>{student.contact}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="profile-update">
        <h2>Update Profile</h2>
        <form onSubmit={handleProfileUpdate}>
          <label>
            Office Hours:
            <input
              type="text"
              name="officeHours"
              value={profile.officeHours}
              onChange={handleProfileChange}
              disabled={!isEditing}
            />
          </label>
          <label>
            Email:
            <input
              type="email"
              name="email"
              value={profile.email}
              onChange={handleProfileChange}
              disabled={!isEditing}
            />
          </label>
          <label>
            Phone:
            <input
              type="tel"
              name="phone"
              value={profile.phone}
              onChange={handleProfileChange}
              disabled={!isEditing}
            />
          </label>
          {isEditing ? (
            <button type="submit">Save</button>
          ) : (
            <button type="button" onClick={() => setIsEditing(true)}>
              Edit
            </button>
          )}
        </form>
      </div>
    </div>
  );
};

export default FacultyDashboard;
