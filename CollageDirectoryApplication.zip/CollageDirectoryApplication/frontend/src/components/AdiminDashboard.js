import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axiosInstance";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const AdminDashboard = () => {
  const [students, setStudents] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [newStudent, setNewStudent] = useState({
    name: "",
    email: "",
    department: "",
  });
  const [newFaculty, setNewFaculty] = useState({
    name: "",
    email: "",
    department: "",
  });
  const [studentData, setStudentData] = useState([]);
  const [facultyData, setFacultyData] = useState([]);

  // Fetch Students and Faculty on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const studentRes = await axiosInstance.get("/admin/students");
        const facultyRes = await axiosInstance.get("/admin/faculty");
        setStudents(studentRes.data);
        setFaculty(facultyRes.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchData();
  }, []);

  // Handle student form input
  const handleStudentInput = (e) => {
    const { name, value } = e.target;
    setNewStudent({ ...newStudent, [name]: value });
  };

  // Handle faculty form input
  const handleFacultyInput = (e) => {
    const { name, value } = e.target;
    setNewFaculty({ ...newFaculty, [name]: value });
  };

  // Add new student
  const addStudent = async () => {
    try {
      const res = await axiosInstance.post("/admin/students", newStudent);
      setStudents([...students, res.data]);
      setNewStudent({ name: "", email: "", department: "" });
    } catch (error) {
      console.error("Error adding student:", error);
    }
  };

  // Add new faculty
  const addFaculty = async () => {
    try {
      const res = await axiosInstance.post("/admin/faculty", newFaculty);
      setFaculty([...faculty, res.data]);
      setNewFaculty({ name: "", email: "", department: "" });
    } catch (error) {
      console.error("Error adding faculty:", error);
    }
  };

  // Delete student
  const deleteStudent = async (id) => {
    try {
      await axiosInstance.delete(`/admin/students/${id}`);
      setStudents(students.filter((student) => student._id !== id));
    } catch (error) {
      console.error("Error deleting student:", error);
    }
  };

  // Delete faculty
  const deleteFaculty = async (id) => {
    try {
      await axiosInstance.delete(`/admin/faculty/${id}`);
      setFaculty(faculty.filter((member) => member._id !== id));
    } catch (error) {
      console.error("Error deleting faculty:", error);
    }
  };

  // Fetch dashboard data (for graphs)
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const studentStats = await axiosInstance.get("/admin/stats/students");
        const facultyStats = await axiosInstance.get("/admin/stats/faculty");
        setStudentData(studentStats.data);
        setFacultyData(facultyStats.data);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      }
    };
    fetchDashboardData();
  }, []);

  return (
    <div className="admin-dashboard">
      {/* Section A: Manage Student Records */}
      <section className="manage-section">
        <h2>Manage Student Records</h2>
        <div>
          <input
            type="text"
            name="name"
            value={newStudent.name}
            placeholder="Student Name"
            onChange={handleStudentInput}
          />
          <input
            type="email"
            name="email"
            value={newStudent.email}
            placeholder="Student Email"
            onChange={handleStudentInput}
          />
          <input
            type="text"
            name="department"
            value={newStudent.department}
            placeholder="Student Department"
            onChange={handleStudentInput}
          />
          <button onClick={addStudent}>Add Student</button>
        </div>

        <ul>
          {students.map((student) => (
            <li key={student._id}>
              {student.name} - {student.email} - {student.department}
              <button onClick={() => deleteStudent(student._id)}>Delete</button>
            </li>
          ))}
        </ul>
      </section>

      {/* Section A: Manage Faculty Records */}
      <section className="manage-section">
        <h2>Manage Faculty Records</h2>
        <div>
          <input
            type="text"
            name="name"
            value={newFaculty.name}
            placeholder="Faculty Name"
            onChange={handleFacultyInput}
          />
          <input
            type="email"
            name="email"
            value={newFaculty.email}
            placeholder="Faculty Email"
            onChange={handleFacultyInput}
          />
          <input
            type="text"
            name="department"
            value={newFaculty.department}
            placeholder="Faculty Department"
            onChange={handleFacultyInput}
          />
          <button onClick={addFaculty}>Add Faculty</button>
        </div>

        <ul>
          {faculty.map((member) => (
            <li key={member._id}>
              {member.name} - {member.email} - {member.department}
              <button onClick={() => deleteFaculty(member._id)}>Delete</button>
            </li>
          ))}
        </ul>
      </section>

      {/* Section B: Dashboard with Graphs */}
      <section className="dashboard-section">
        <h2>Admin Dashboard</h2>
        <div className="charts">
          <h3>Student Enrollment Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={studentData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="students" stroke="#8884d8" />
            </LineChart>
          </ResponsiveContainer>

          <h3>Faculty Course Loads</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={facultyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="faculty" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="courses" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
    </div>
  );
};

export default AdminDashboard;
