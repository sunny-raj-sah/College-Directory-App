// src/components/Home.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../App.css"; // Assume common CSS is here

const Home = () => {
  const [role, setRole] = useState("student"); // Default role is student
  const navigate = useNavigate();

  const handleRoleChange = (e) => setRole(e.target.value);

  const handleSignup = () => navigate("/signup");
  const handleLogin = () => navigate("/login");

  return (
    <div className="home-container">
      <h1>Welcome to the College Directory</h1>
      <select value={role} onChange={handleRoleChange}>
        <option value="student">Student</option>
        <option value="faculty">Faculty</option>
        <option value="administrator">Administrator</option>
      </select>
      <div className="auth-buttons">
        <button onClick={handleSignup}>Signup as {role}</button>
        <button onClick={handleLogin}>Login as {role}</button>
      </div>
    </div>
  );
};

export default Home;
